/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desenho;

import java.awt.Graphics;

/**
 *
 * @author Andr� Luiz F. Lima.
 */
public class Primitive {

    public static void drawPixel(Graphics g, int x, int y) {
        g.drawLine(x, y, x, y);
    }

    public static void drawHLine(Graphics g, int x1, int x2, int y) {
        for (int i = x1; i <= x2; i++) {
            g.drawLine(i, y, i, y);
        }
    }

    public static void drawVLine(Graphics g, int y1, int y2, int x) {
        for (int i = y1; i <= y2; i++) {
            g.drawLine(x, i, x, i);
        }
    }

    public static void drawLine(Graphics g, int x1, int y1, int x2, int y2) {

        //Calculo do M
    	double m = ((double) y1 - (double) y2) / ((double) x1 - (double) x2);
        
    	//Calculo do B
    	double b = m * (double) x1 - (double) y1;

        System.out.println("M:" + m);
        System.out.println("B:" + b);

        double y = 0;

        for (int i = x1; i <= x2; i++) {
            y = m * i + b;
            System.out.println("Y: " + y);
            drawPixel(g, i, (int) (m * i + b));
        }
    }
}
